import React, { useState, useEffect } from "react";
import axios from "axios";

function App()
{

  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [users, setUsers] = useState([]);

  const getUsers = async () =>
  {
    const res = await axios.get("http://localhost:5050/users");
    setUsers(res.data);
  };

  useEffect(() =>
  {
    getUsers();
  }, []);

  const addUser = async () =>
  {

    await axios.post("http://localhost:5050/adduser", {
      username,
      email,
      password
    });

    getUsers();
  };

  return (
    <div style={{ padding: "20px" }}>

      <h2>Add User</h2>

      <input
        type="text"
        placeholder="Username"
        onChange={(e) => setUsername(e.target.value)}
      />

      <br /><br />

      <input
        type="email"
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
      />

      <br /><br />

      <input
        type="password"
        placeholder="Password"
        onChange={(e) => setPassword(e.target.value)}
      />

      <br /><br />

      <button onClick={addUser}>
        Add User
      </button>

      <hr />

      <h2>User List</h2>

      {users.map((u) => (
        <div key={u._id}>
          {u.username} | {u.email} | {u.password}
        </div>
      ))}

    </div>
  );
}

export default App;