const express = require("express");
const { MongoClient } = require("mongodb");
const cors = require("cors");

const app = express();
const port = 5050;

app.use(cors());
app.use(express.json());   // IMPORTANT

const MONGOURL = "mongodb://admin:qwerty@localhost:27017";
const client = new MongoClient(MONGOURL);

// Add User
app.post("/adduser", async (req, res) =>
{
    try
    {

        const userobj = req.body;

        await client.connect();
        console.log("Connected to MongoDB");

        const db = client.db("testdb");

        const data = await db.collection("users").insertOne(userobj);

        res.send({
            message: "User inserted successfully",
            data: data
        });

    } catch (err)
    {
        res.send(err);
    }
});

// Fetch Users
// http://localhost:5050/users
app.get("/users", async (req, res) =>
{

    await client.connect();

    const db = client.db("testdb");

    const data = await db.collection("users").find({}).toArray();

    res.send(data);
});

app.listen(port, () =>
{
    console.log("Server running on port " + port);
});