import { Route, Routes, useLocation } from "react-router-dom";
import Home from "./Home/Home";
import AdminHome from "./Home/AdminHome";
import TeacherHome from "./Home/TeacherHome";
import StudentHome from "./Home/StudentHome";
import Authpage from "./Authpage";
import { useEffect } from "react";
import Overview from "./AboutUs/Overview";
import Recognition from "./AboutUs/Recognition";
import Departmental_Activities from "./AboutUs/Departmental_Activities";
import Holiday_List from "./AboutUs/Holiday_List";
import Contact from "./AboutUs/Contact";
import Director from "./Administration/Director";
import Rules_guide from "./Administration/Rules_guide";
import Academic_Overview from "./Academics/Academic_Overview";
import Programmes from "./Academics/Programmes";
import Mtech_Ai from "./Academics/Mtech_Ai";
import Mtech_Es from "./Academics/Mtech_Es";
import Mtech_Vlsi from "./Academics/Mtech_Vlsi";
import Academic_Calender from "./Academics/Academic_Calender";
import Syllabus from "./Academics/Syllabus";
import Fees_Structure from "./Academics/Fees_Structure";
import Procedure from "./Admissions/Procedure";
import Eligibility_criteria from "./Admissions/Eligibility_criteria";
import Admission_help from "./Admissions/Admission_help";
import Hod from "./People/Hod";
import List_of_faculty from "./People/List_of_faculty";
import Staff from "./People/Staff";
import SponsoredProjects from "./Research/SponsoredProjects";
import StudentProjects from "./Research/StudentProjects";
import Library from "./Facilities/Library";
import Laboratories from "./Facilities/Laboratories";
import Hostel from "./Facilities/Hostel";
import PoMessage from "./Placement/PoMessage";
import Placement_acsd from "./Placement/Placement_acsd";
import Contact_Po from "./Placement/Contact_Po";
import AntiRagging from "./StudentCorner/AntiRagging";
import StudentCounselling from "./StudentCorner/StudentCounselling";
import Sports from "./StudentCorner/Sports";
import Privacy_policy from "./Privacy_policy";
import SeatDistribution from "./Admissions/SeatDistribution";
import Student_Login from "./Login/Student_Login";
import TeacherList from "./Backend/Admin/AllTeacherList_ToAdmin";
import SearchTeacher from "./Backend/Admin/SearchTeacher_ByAdmin";
import UpdateTeacher from "./Backend/Admin/UpdateTeacher_ByAdmin";
import StudentList from "./Backend/Teacher/AllStudentList_ToTeacher";
import AddStudent from "./Backend/Teacher/AddStudent_ByTeacher";
import UpdateStudent from "./Backend/Teacher/UpdateStudent_ByTeacher";
import SearchStudent from "./Backend/Teacher/SearchStudent_ByTeacher";
import AllStudentList from "./Backend/Admin/AllStudentList_ToAdmin";
import AddStudent_byadmin from "./Backend/Admin/AddStudent_ByAdmin";
import UpdateStudent_byAdmin from "./Backend/Admin/UpdateStudent_byAdmin";
import SearchStudent_byAdmins from "./Backend/Admin/SearchStudent_ByAdmin";
import AddTeacher_byadmin from "./Backend/Admin/AddTeacher_ByAdmin";
import StudentAddedByTeacher from "./Backend/Teacher/StudentAdded_ByTeacher";
import StudentAddedByAdmin from "./Backend/Admin/StudentAdded_ByAdmin";
import AdminProfile from "./Backend/Admin/AdminProfile";
import EditAdminProfile from "./Backend/Admin/EditAdminProfile";
import ChangePassword_ByAdmin from "./Backend/Admin/ChangePassword_ByAdmin";
import ChangePassword_ByTeacher from "./Backend/Teacher/ChangePassword_ByTeacher";
import TeacherProfile from "./Backend/Teacher/TeacherProfile";
import EditTeacherProfile from "./Backend/Teacher/EditTeacherProfile";


function Siteroutes()
{

    const location = useLocation();

    useEffect(() =>
    {
        window.scrollTo(0, 0);
    }, [location.pathname]);

    return (
        <div>
            <Routes>
                <Route path="/" element={<Home />}></Route>
                <Route path="/adminhome" element={<AdminHome />}></Route>
                <Route path="/teacherhome" element={<TeacherHome />}></Route>
                <Route path="/studenthome" element={<StudentHome />}></Route>
                <Route path="/staff_login" element={<Authpage />}></Route>
                <Route path="/staff_register" element={<Authpage />}></Route>
                <Route path="/student_login" element={<Student_Login />}></Route>
                <Route path="/overview" element={<Overview />}></Route>
                <Route path="/recognition" element={<Recognition />}></Route>
                <Route path="/departmental_activities" element={<Departmental_Activities />}></Route>
                <Route path="/holidays_list" element={<Holiday_List />}></Route>
                <Route path="/contact" element={<Contact />}></Route>
                <Route path="/director" element={<Director />}></Route>
                <Route path="/rules_guidelines" element={<Rules_guide />}></Route>
                <Route path="/academic_overview" element={<Academic_Overview />}></Route>
                <Route path="/programmes" element={<Programmes />}></Route>
                <Route path="/mtech_ai" element={<Mtech_Ai />}></Route>
                <Route path="/mtech_es" element={<Mtech_Es />}></Route>
                <Route path="/mtech_vlsi" element={<Mtech_Vlsi />}></Route>
                <Route path="/academic_calendar" element={<Academic_Calender />}></Route>
                <Route path="/syllabus" element={<Syllabus />}></Route>
                <Route path="/fees_structure" element={<Fees_Structure />}></Route>
                <Route path="/procedure" element={<Procedure />}></Route>
                <Route path="/eligibility_criteria" element={<Eligibility_criteria />}></Route>
                <Route path="/admission_helpline" element={<Admission_help />}></Route>
                <Route path="/hod" element={<Hod />}></Route>
                <Route path="/list_of_faculty" element={<List_of_faculty />}></Route>
                <Route path="/staff" element={<Staff />}></Route>
                <Route path="/sponsored_projects" element={<SponsoredProjects />}></Route>
                <Route path="/student_projects" element={<StudentProjects />}></Route>
                <Route path="/library" element={<Library />}></Route>
                <Route path="/laboratories" element={<Laboratories />}></Route>
                <Route path="/hostel" element={<Hostel />}></Route>
                <Route path="/po_message" element={<PoMessage />}></Route>
                <Route path="/placement_acsd" element={<Placement_acsd />}></Route>
                <Route path="/contact_po" element={<Contact_Po />}></Route>
                <Route path="/antiragging" element={<AntiRagging />}></Route>
                <Route path="/studentcounselling" element={<StudentCounselling />}></Route>
                <Route path="/sports" element={<Sports />}></Route>
                <Route path="/privacy_policy" element={<Privacy_policy />}></Route>
                <Route path="/seat_distribution" element={<SeatDistribution />}></Route>



                {/* backend start */}

                {/* admin */}
                <Route path="/adminPanel" element={<TeacherList />}></Route>
                <Route path="/update_teacher_by_admin/:tid" element={<UpdateTeacher />}></Route>
                <Route path="/search_teacher" element={<SearchTeacher />}></Route>
                <Route path="/all_students_list_to_admin" element={<AllStudentList />}></Route>
                <Route path="/add_student_byadmin" element={<AddStudent_byadmin />}></Route>
                <Route path="/add_teacher_byAdmin" element={<AddTeacher_byadmin />}></Route>
                <Route path="/update_student_by_admin/:sid" element={<UpdateStudent_byAdmin />}></Route>
                <Route path="/search_student_byAdmin" element={<SearchStudent_byAdmins />}></Route>
                <Route path="/student_add_by_Admin" element={<StudentAddedByAdmin />}></Route>
                <Route path="/adminprofile" element={<AdminProfile />}></Route>
                <Route path="/edit_profile_of_admin" element={<EditAdminProfile />}></Route>
                <Route path="/changepassword_for_admin" element={<ChangePassword_ByAdmin />}></Route>


                {/* teacher */}
                <Route path="/teacherPanel" element={<StudentList />}></Route>
                <Route path="/add_student" element={<AddStudent />}></Route>
                <Route path="/update_student_by_teacher/:sid" element={<UpdateStudent />}></Route>
                <Route path="/search_student" element={<SearchStudent />}></Route>
                <Route path="/student_add_by_teacher" element={<StudentAddedByTeacher />}></Route>
                <Route path="/teacherprofile" element={<TeacherProfile />}></Route>
                <Route path="/edit_profile_of_teacher" element={<EditTeacherProfile />}></Route>
                <Route path="/changepassword_for_teacher" element={<ChangePassword_ByTeacher />}></Route>

                

            </Routes>
        </div>
    )
}

export default Siteroutes
