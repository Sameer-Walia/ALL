function myFunction(event)
{
    event.preventDefault()                      // it will prevent form to get submit or prevents page to reload
    const name = document.getElementById("name").value
    const email = document.getElementById("email").value
    const phone = document.getElementById("phone").value
    createuser(name, email, phone);
}

async function createuser(name, email, phone)
{
    try
    {
        // in crudcrud api expires after 24 hours . u h ave to get new api 
        const res = await fetch("https://crudcrud.com/api/d9cbddcce08a4657a93fca756e8cb73a/records",
            {
                method: "POST",
                headers:
                {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ name: name, email: email, phone: phone })
            })
        const data = await res.json();

        // Handle the response data
        console.log("User created:", data);

        // Clear the form fields
        document.getElementById("name").value = ""
        document.getElementById("email").value = ""
        document.getElementById("phone").value = ""

        // Refresh the user list
        await getusers();
    }
    catch (err)
    {
        console.log("Error creating user", err)
    }
}


/* Function to get all users */
async function getusers()
{
    try
    {
        const res = await fetch("https://crudcrud.com/api/d9cbddcce08a4657a93fca756e8cb73a/records");
        const data = await res.json()

        // Clear the user list
        document.getElementById("userdata").innerHTML = "";
        // document.getElementById("userdata").textContent = "";

        // Populate the user list
        data.forEach(user =>
        {
            const row = document.createElement("tr")
            const namecell = document.createElement("td")
            namecell.textContent = user.name
            /* document.createElement("td").innerHTML=user.name */
            row.appendChild(namecell);

            const emailcell = document.createElement("td")
            emailcell.textContent = user.email
            row.appendChild(emailcell)

            const phonecell = document.createElement("td")
            phonecell.textContent = user.phone
            row.appendChild(phonecell)

            const updatecell = document.createElement("td")
            const updatelink = document.createElement("button")
            updatelink.textContent = "Update"
            updatelink.addEventListener("click", function ()
            {
                const newname = prompt("Enter new name")
                const newemail = prompt("Enter new email id")
                const newphone = prompt("Enter new phone no")
                updateuser(user._id, newname, newemail, newphone)
            })
            updatecell.appendChild(updatelink)
            row.appendChild(updatecell)

            const deletecell = document.createElement("td")
            const deletelink = document.createElement("a")
            deletelink.href = "#"
            deletelink.textContent = "Delete"
            deletelink.addEventListener("click", function ()
            {
                const conf = confirm("Are you sure to delete the user");
                if (conf == true)
                {
                    deleteuser(user._id)
                }
            })
            deletecell.appendChild(deletelink)
            row.appendChild(deletecell)

            userlist.appendChild(row)
        })
    }
    catch (err)
    {
        console.log("Error getting users ", err)
    }
}

/* Function to update a user */
async function updateuser(id, name, email, phone)
{
    try
    {
        const res = await fetch(`https://crudcrud.com/api/d9cbddcce08a4657a93fca756e8cb73a/records/${id}`,
            {
                method: "PUT",
                headers:
                {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ name: name, email: email, phone: phone })
            });
        const data = await res.json();

        // Handle the response data
        console.log("User updated: ", data);

        // Refresh the user list
        await getusers();
    }
    catch (err)
    {
        console.log("error updating user", err);
    }
}

/* Function to delete a user */
async function deleteuser(id)
{
    try
    {
        await fetch(`https://crudcrud.com/api/d9cbddcce08a4657a93fca756e8cb73a/records/${id}`,
            {
                method: "DELETE"
            });

        // Handle the response data
        console.log("User Deleted");

        // Refresh the user list
        await getusers();
    }
    catch (err)
    {
        console.log("Error deleting user:", err);
    }
}

// Initial load - get all users
getusers()
