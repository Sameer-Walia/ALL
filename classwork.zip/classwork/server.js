const express = require('express')
const app = express()
const port = 9000
app.use(express.json());

app.get('/', (req, res) => {
    res.send("node server is runings")
})

app.get('/showmsg', (req, res) => {
    // http://localhost:9000/showmsg?pn=sam&age=21
    res.send(`welcome ${req.query.pn}. Your age is ${req.query.age}`)
})

app.get('/showmsg/:pname/:age/:gen', (req, res) => {
    // http://localhost:9000/showmsg/rahul/21/male
    res.send(`welcome ${req.params.pname}. Your age is ${req.params.age}. Your Gender is ${req.params.gen}`)
})


app.post("/welcome", (req, res) => 
{
    // var pname = req.body.name;
    // var age = req.body.age;
    // var gen = req.body.gender;
    // console.log(pname);
    // res.send(`Welcome ${pname}. Your age is ${age}. Gender is ${gen}`)

    res.send(`Welcomes ${req.body.name}. Your age is ${req.body.age}. Gender is ${req.body.gender}`)

})

app.listen(port,()=>
{
    console.log("server is running on port  "+port)
})