import { useEffect, useState } from "react";
function UseEffect()
{
    const[fno , setfno] = useState()
    const[sno , setsno] = useState()
    const[sum , setsum] = useState(null)
    const[final , setfinal] = useState()

    function calsum()
    {
        setsum( Number(fno) + parseInt(sno))   //async task will be start but it will be finished later on
    }

    useEffect( ()=>
    {
        if(sum!==null)
        {
            setfinal(Number(sum)+500)
        }
    },[sum])


    useEffect( ()=>
    {
        console.log("Hello")
    })
    
    
    return(
        <>
            <br/><br/><input type="text" name="fno" placeholder="Enter First  Number" onChange={(e)=>setfno(e.target.value)}></input><br/><br/>
            <input type="text" name="sno" placeholder="Enter Second Number" onChange={(e)=>setsno(e.target.value)}></input><br/><br/>
            <button onClick={calsum}>Sum</button><br/><br/>
            sum:- {sum}<br/><br/>
            {final}
        </>
    )
}
export default UseEffect;