import {Link} from "react-router-dom";
import topbanner from "./images/onlineshopping.jpeg"
import SiteRoutes from "./components/SiteRoutes";

function RoutingTable()
{
    return(
        <>
            <table border="1" width="1000px" align="center">
                <tbody>
                    <tr align="right">
                        <td colSpan="6"><Link to="/SignUppage">SignUp</Link>   <Link to="/Loginpage">Login</Link></td>
                    </tr>
                    <tr>
                        <td colSpan="6"><img src={topbanner} width="1000" height="200"></img></td>
                    </tr>
                    <tr align="center">
                        <td><Link to="/homepage">Home</Link></td>
                        <td><Link to="/aboutpage">About Us</Link></td>
                        <td><Link to="/productpage">Produts</Link></td>
                        <td><Link to="/searchpage">Search</Link></td>
                        <td><Link to="/contactpage">Contact</Link></td>
                        <td><Link to="/feedbackpage">Feedback</Link></td>
                    </tr>
                    <tr>
                        <td colSpan="6">
                            <SiteRoutes/>
                        </td>
                    </tr>
                    <tr align="center">
                        <td colSpan="6">&copy;GTB Computer Education</td>
                    </tr>
                </tbody>
            </table>
        </>
    )
}
export default RoutingTable;