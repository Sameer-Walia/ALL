import { useState } from "react";

function CheckBox()
{
    const[item1 , setitem1] = useState(false)
    const[item2 , setitem2] = useState(false)
    const[item3 , setitem3] = useState(false)
    const[ptot , setptot] = useState()

    function caltotal()
    {
        var tot = 0 // synchronius function and js variable

        if(item1===true)
        {
            tot = tot+250
        }
        if(item2===true)
        {
            tot = tot+80
        }
        if(item3===true)
        {
            tot = tot+50
        }
        setptot(tot)
    }

    return(
        <>
            <br/><br/><input type="checkbox" name="cb1" onChange={(e)=>setitem1(e.target.checked)}></input>Pizza - Rs-250/- <br/>
            <input type="checkbox" name="cb2" onChange={(e)=>setitem2(e.target.checked)}></input>Burger - Rs-80/- <br/>
            <input type="checkbox" name="cb3" onChange={(e)=>setitem3(e.target.checked)}></input>Cold Drink - Rs-50/- <br/><br/>

            <button name="btn" onClick={caltotal}>Calculate total</button><br/><br/>
            Total is {ptot}
        </>
    )
}
export default CheckBox;