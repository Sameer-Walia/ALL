import './App.css';
import CheckBox from './CheckBox';
import Eventhandling from './Eventhandling';
import Mapping from './Mapping';
import Mapping1 from './Mapping1';
import Practice from './Practice';
import RadioButton from './RadioButton';
import RoutingTable from './RoutingTable';
import SelectBox from './SelectBox';
import Signup from './Signup';
import Sum from './Sum';
import TerniaryOperator from './TerniaryOperator';
import UpdateName from './UpdateName';
import UseEffect from './UseEffect';
import UseEffect1 from './UseEffect1';
import UseState from './UseState';

function App() {
  return (
    <div >
        {/* <Eventhandling/> */}
        {/* <UseState/> */}
        {/* <TerniaryOperator/> */}
        {/* <Sum/> */}
        {/* <Signup/> */}
        {/* <UpdateName/> */}
        {/* <UseEffect/> */}
        {/* <UseEffect1/> */}
        {/* <RadioButton/> */}
        {/* <SelectBox/> */}
        {/* <CheckBox/> */}
        {/* <Mapping/> */}
        {/* <Mapping1/> */}

        {/* <RoutingTable/> */}
        <Practice/>

    </div>
  );
}

export default App;
