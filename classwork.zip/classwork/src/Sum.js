import { useState } from "react";

function Sum()
{
    const[fno , setfno] = useState()
    const[sno , setsno] = useState()
    const[sum , setsum] = useState()

    function calsum()
    {
        setsum( Number(fno) + parseInt(sno))
    }

    return(
        <>
            <br/><br/><input type="text" name="fno" placeholder="Enter First  Number" onChange={(e)=>setfno(e.target.value)}></input><br/><br/>
            <input type="text" name="sno" placeholder="Enter Second Number" onChange={(e)=>setsno(e.target.value)}></input><br/><br/>
            <button onClick={calsum}>Sum</button><br/><br/>
            sum {sum}
        </>
    )
}
export default Sum;