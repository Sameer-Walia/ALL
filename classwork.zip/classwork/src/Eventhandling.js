function Eventhandling()
{
    function btnclick1()
    {
      alert("Hello")
    }
  
    function btnclick2(sname)
    {
      alert("Hello " +sname)
    }

    return(
        <>
            <button onClick={btnclick1}>Click Here</button><br/>
            {/* <button onClick={btnclick2("sam")}>Click Here</button> on load it will show */}
            <button onClick={()=>btnclick2("sam")}>Click Here</button><br/><br/>
        </>
    )
}
export default Eventhandling;