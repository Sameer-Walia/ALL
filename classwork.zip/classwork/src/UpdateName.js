import { useState } from "react";

function UpdateName()
{
    const[pname , setpname] = useState("Manish Kumar")

    function updatename()
    {
        setpname("Varun Kumar")
        alert(pname)
    }

    return(
        <>
            <button onClick={updatename}>Update Name</button><br></br><br/>
            {pname}
        </>
    )
}
export default UpdateName;