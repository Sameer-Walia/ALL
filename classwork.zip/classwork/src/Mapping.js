function Mapping()
{
    const students=["Anil" ,"suresh","suresh","aman","rahul"]    // arrays
    return(
        <>
            <ol>
                {
                    students.map((sname , index)=>
                        <li key={index}>{sname}</li>
                    )
                }
            </ol>
        </>
    );
}
export default Mapping;