import { useEffect, useState } from "react";

function Practice()
{
    const[flag , setflag] = useState();
    const[name , setname] = useState();
    const[sal , setsal] = useState();
    const[gen , setgen] = useState();
    const[item1 , setitem1] = useState(false);
    const[item2 , setitem2] = useState(false);
    const[dep , setdep] = useState();
    const[info , setinfo] = useState();
    const[bonus , setbonus] = useState();
    const[qual , setqual] = useState();
    const[tot , settot] = useState();


    function sub()
    {
        setflag(true)
        if(gen==="male" && sal<10000 && dep==="purchase")
        {
            setinfo("Bonus 50% of salary")
            setbonus((sal*50)/100);
        }
        else if(gen==="female" && sal<10000 && dep==="purchase")
        {
            setinfo("Bonus 55% of salary")
            setbonus((sal*55)/100);
        }
        else if(gen==="male" && sal<10000 && dep==="sales")
        {
            setinfo("Bonus 70% of salary")
            setbonus((sal*70)/100);
        }
        else if(gen==="female" && sal<10000 && dep==="sales")
        {
            setinfo("Bonus 75% of salary")
            setbonus((sal*75)/100);
        }
        else
        {
            setinfo("0 bonus because your salary is above 9999")
            setbonus(0);
        }
    }

    useEffect(()=>
    {
        setqual((item1?1500:0)+(item2?1000:0))
    }, [item1 , item2])

    useEffect(()=>
    {
        settot( Number(sal) + Number(bonus) + Number(qual) )
    }, [bonus , qual])


    return(
        <>
            Enter Your Name :- <input type="text" name="name" placeholder="Sam..." onChange={(e)=>setname(e.target.value)}></input><br/><br/>

            Enter Your Salary :-<input type="text" name="sal" placeholder="10000" onChange={(e)=>setsal(e.target.value)}></input><br/><br/>

            Choose Gender :-<label><input type="radio" name="gen" value="male" onChange={(e)=>setgen(e.target.value)}></input>Male</label>
            <label><input type="radio" name="gen" value="female" onChange={(e)=>setgen(e.target.value)}></input>Female</label><br/><br/>

            Choose Quality :-<label><input type="checkbox" name="cb1" value="hardworking" onChange={(e)=>setitem1(e.target.checked)}></input>Hardworking</label>
            <label><input type="checkbox" name="cb2" value="punctual" onChange={(e)=>setitem2(e.target.checked)}></input>Punctual</label><br/><br/>

            Choose Department :-
            <select name="dep" onChange={(e)=>setdep(e.target.value)}>
                <option value="purchase">Purchase</option>
                <option value="sales">Sales</option>
            </select><br/><br/>

            <button type="submit" onClick={sub}>Submit</button><br/><br/>

            {
                flag===true?
                <>
                    Your Name is {name}<br/><br/>
                    Your Salary is {sal}<br/><br/>
                    Your Gender is {gen}<br/><br/>
                    Your Department is {dep}<br/><br/>
                    You will get {info}<br/><br/>
                    Your Bonus is {bonus}<br/><br/>
                    Your Quality Bonus is {qual}<br/><br/>
                    Your Total Salary is {tot}<br/><br/>

                </>:null
            }
        </>
    )
}
export default Practice;