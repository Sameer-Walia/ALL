import { useState } from 'react';
function UseState()
{
    const [pname , setpname] = useState("Harish");
    const[age]=useState(21);
    const[gender , setgender]=useState();
    function changename()
    {
      setpname("Harish Sharma")
      setgender("Male")
    }

    return(
        <>
            <h1>{pname}</h1>
            <h2>{age}</h2>
            <h2>{gender}</h2>
            <button onClick={changename}>Click Here</button><br></br>
        </>
    )
}
export default UseState;