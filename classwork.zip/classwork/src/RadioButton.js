import { useState } from "react";

function RadioButton()
{
    const[gen , setgen] = useState()
    const[msg , setmes] = useState()

    function onsignup()
    {
        if(gen==="male")
        {
            setmes("you won a trip to Singapore")
        }
        else if(gen==="f")
        {
            setmes("you won a trip to Malaysia")
        }
    }


    return(
        <>
            <label><input type="radio" name="gender" value="male" onChange={(e)=>setgen(e.target.value)}></input>Male</label>
            <label><input type="radio" name="gender" value="f" onChange={(e)=>setgen(e.target.value)}></input>Female</label><br/><br/>
            <button name="btn" onClick={onsignup}>Calculate</button><br/><br/>
            {msg}
        </>
    )
}
export default RadioButton;