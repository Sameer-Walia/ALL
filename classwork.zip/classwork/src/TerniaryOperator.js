import { useState } from 'react';
function TerniaryOperator()
{
    const[flag , setflag]=useState(true);

    // function hidemsg()
    // {
    //   setflag(false)
    // }
    // function showmsg()
    // {
    //   setflag(true)
    // }
    function changestatus()
    {
        setflag(!flag)
    }
  
    return(
        <>
            {
                flag===true? 
                <>        
                    <h1>Welcome to Reactjs</h1>
                    <h1>Welcome to Coding</h1>
                </>:null
            }
            {/* <button onClick={hidemsg}>Hide</button>
            <button onClick={showmsg}>Show</button> */}
            <button onClick={changestatus}>Hide/Show</button>
        </>
    )
}
export default TerniaryOperator;