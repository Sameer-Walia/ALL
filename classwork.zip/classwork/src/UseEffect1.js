import { useEffect, useState } from "react";
function UseEffect1()
{
    const[p , setp] = useState()
    const[r , setr] = useState()
    const[t, sett] = useState()
    const[si , setsi] = useState(null)
    const[tamt , settamt] = useState()
    const[flag , setflag] = useState(false)

    function calsi()
    {
        setflag(true)
        setsi( (Number(p)*parseInt(r)*parseInt(t))/100) 
        
    }

    useEffect( ()=>
    {
        if(si!==null)
        {
            settamt(Number(si)+Number(p))
        }
    },[si])

    
    return(
        <>
            <br/><br/><input type="text" name="p" placeholder="Principal" onChange={(e)=>setp(e.target.value)}></input><br/><br/>
            <input type="text" name="r" placeholder="Rate" onChange={(e)=>setr(e.target.value)}></input><br/><br/>
            <input type="text" name="t" placeholder="Time" onChange={(e)=>sett(e.target.value)}></input><br/><br/>
            <button onClick={calsi}>Simple Interest</button><br/><br/>
            {
                flag===true?
                <>
                    Simple Interset:- {si}<br/><br/>
                    Total Amount   :-{tamt}
                </>:null
            }
            
        </>
    )
}
export default UseEffect1;