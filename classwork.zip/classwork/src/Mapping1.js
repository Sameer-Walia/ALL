function Mapping1()
{
    const students = [{name : "Varun" , Age : 5 , gender :"Male"},
                    {name : "Sameer" , Age : 21 , gender :"Male"},
                    {name : "Nandini" , Age : 19 , gender :"Female"},
                    {name : "Upasna" , Age : 20 , gender :"Female"} ]
    return(
        <>
            <table width="700" border="1" align="center">
                <tbody>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Gender</th>
                    </tr>
                    {
                        students.map((sdata , index)=>
                            <tr key={index} align="center">
                                <td>{sdata.name}</td>
                                <td>{sdata.Age}</td>
                                <td>{sdata.gender}</td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </>
    )
}
export default Mapping1;