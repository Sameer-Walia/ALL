import { Link } from "react-router-dom";
import prod1 from "../images/Motorola-Edge.webp"
import prod2 from "../images/Realme-GT5.webp"
import prod3 from "../images/pocom6.jpg"


function Products()
{
    return(
        <>
            <h1 align="center">Products</h1>
            <table width="750" align="center"> 
                <tbody>
                    <tr>
                        <td>
                            <Link to="/detailpage?pid=101">
                                <img src={prod1} alt="product1" height="200"></img><br/>
                                Motorola-Edge
                            </Link>
                        </td>
                        <td>
                            <Link to="/detailpage?pid=102">
                                <img src={prod2} alt="product1" height="200"></img><br/>
                                Realme-GT5
                            </Link>
                        </td>
                        <td>
                            <Link to="/detailpage?pid=103">
                                <img src={prod3} alt="product1" height="200"></img><br/>
                                Pocom6
                            </Link>
                        </td>
                    </tr>
                </tbody>
            </table>
        </>
    )
}
export default Products;