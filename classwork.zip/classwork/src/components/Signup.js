import { useState } from "react";
import { useNavigate } from "react-router-dom";

function About()
{
    const[uname , setuname] = useState();
    const[upass , setupass] = useState();
    const[msg , setmsg] = useState();
    
    const navi = useNavigate();

    function sign()
    {
        if(uname==="GTB" && upass==="123")
        {
            navi("/homepage")
        }
        else
        {
            setmsg("Incorrect Username/Password")
        }
    }
    return(
        <>
            <h1>Welcome to SignUp Page</h1>
            <input type="text" placeholder="Username" name="uname" onChange={(e)=>setuname(e.target.value)}></input><br/><br/>
            <input type="password" placeholder="Password" name="upass" onChange={(e)=>setupass(e.target.value)}></input><br/><br/>
            <button onClick={sign}>SignIn</button><br/><br/>
            {msg}
        </>
    )
}
export default About;