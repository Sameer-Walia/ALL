import {Route, Routes } from "react-router-dom";
import Home from "./Home"
import About from "./About"
import Produts from "./Products"
import Search from "./Search"
import Contact from "./Contact"
import Feedback from "./Feedback"
import Signup from "./Signup"
import Login from "./Login"
import Details from "./Details";


function SiteRoutes()
{
    return(
        <>
            <Routes>
                <Route path="" element={<Home/>}></Route>
                <Route path="/homepage" element={<Home/>}></Route>
                <Route path="/aboutpage" element={<About/>}></Route>
                <Route path="/productpage" element={<Produts/>}></Route>
                <Route path="/searchpage" element={<Search/>}></Route>
                <Route path="/contactpage" element={<Contact/>}></Route>
                <Route path="/feedbackpage" element={<Feedback/>}></Route>
                <Route path="/SignUppage" element={<Signup/>}></Route>
                <Route path="/Loginpage" element={<Login/>}></Route>
                <Route path="/detailpage" element={<Details/>}></Route>
                <Route path="*" element={<h1>Page Not Found</h1>}></Route>
            </Routes>
        </>
    )
}
export default SiteRoutes;