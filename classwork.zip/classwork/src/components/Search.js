function Search()
{
    return(
        <>
            <h1>Welcome to Search Page</h1>
        </>
    )
}
export default Search;