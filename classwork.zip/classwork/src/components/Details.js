import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import prod1 from "../images/Motorola-Edge.webp"
import prod2 from "../images/Realme-GT5.webp"
import prod3 from "../images/pocom6.jpg"

function Details()
{
    const [params] = useSearchParams();
    const proid = params.get("pid");

    const[name , setname] = useState();
    const[rate , setrate] = useState();
    const[ph , setph] = useState();

    useEffect(()=>
    {
        if(proid==="101")
        {
            setph(<img src={prod1} alt="product1" height="200"></img>)
            setname("Motorola-Edge");
            setrate("Rs.40000")
        }
        else if(proid==="102")
        {
            setph(<img src={prod2} alt="product2" height="200"></img>)
            setname("Realme-GT5");
            setrate("Rs.22000")
        }
        else if(proid==="103")
        {
            setph(<img src={prod3} alt="product3" height="200"></img>)
            setname("Pocom6");
            setrate("Rs.9999")
        }
    } , [proid])

    return(
        <div align="center">
            <h1 >Product Details</h1>
            {ph}
            <h2>{name}</h2>
            <h2>{rate}</h2>
        </div>
    )
}
export default Details;